#include <string>
#include <new>
#include <iostream>
#include "header.h"

using namespace std;


int main (){

	
	Chave chave;
	chave.inicia();
	if (chave.getNumJogadores() == 1) {
		cout<<"Marroe"<<endl;
		Um_Jogador um_jogador;
		Jogo <Um_Jogador>jogo(chave, um_jogador);
		jogo.start();
		
	}else{
		Dois_Jogadores dois_jogadores;
		
		Jogo <Dois_Jogadores>jogo(chave, dois_jogadores);
		jogo.start();
	}
	
	
	
	/**********
	Jogo <>jogo(chave, (chave.getT_jogador()));
	*************/
	
	
	//chave.inicia(); //tratar erro: tamCod>numCores && coresRepetidas==false
//	chave.setCores();
//	cout<<"EITA BU CE TA BUNITA";
	//
	//chave.setSenha();
	
	//chave.freeAtributos();
	
	
}
